<?php
/**
 * Plugin Name: Roulotte Manager
 * Description: Gestione avanzata per Roulotte Pro: Custom Post Type, Campi Personalizzati, API e Generazione PDF.
 * Version: 1.1.0
 * Author: Trae AI
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// 1. Registrazione Custom Post Type e Tassonomie
function rp_register_cpt() {
    register_post_type( 'roulotte', array(
        'labels' => array(
            'name' => 'Roulottes',
            'singular_name' => 'Roulotte',
            'add_new' => 'Aggiungi Nuova',
            'edit_item' => 'Modifica Roulotte',
            'view_item' => 'Vedi Roulotte',
            'search_items' => 'Cerca Roulottes',
        ),
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true, // Abilita Gutenberg e REST API
        'supports' => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
        'menu_icon' => 'dashicons-car',
        'rewrite' => array( 'slug' => 'catalogo' ),
    ));

    // Tassonomie per filtri rapidi
    register_taxonomy( 'marca', 'roulotte', array(
        'labels' => array( 'name' => 'Marche' ),
        'public' => true,
        'hierarchical' => true,
        'show_in_rest' => true,
    ));
}
add_action( 'init', 'rp_register_cpt' );

// 2. Meta Box Personalizzati (Senza dipendere da ACF)
function rp_add_meta_boxes() {
    add_meta_box( 'rp_details', 'Dettagli Tecnici', 'rp_render_meta_box', 'roulotte', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'rp_add_meta_boxes' );

function rp_render_meta_box( $post ) {
    $values = get_post_custom( $post->ID );
    $prezzo = isset( $values['prezzo'][0] ) ? $values['prezzo'][0] : '';
    $anno = isset( $values['anno'][0] ) ? $values['anno'][0] : '';
    $posti = isset( $values['posti_letto'][0] ) ? $values['posti_letto'][0] : '';
    $peso = isset( $values['peso_massimo'][0] ) ? $values['peso_massimo'][0] : '';
    $lunghezza = isset( $values['lunghezza'][0] ) ? $values['lunghezza'][0] : '';
    $condizione = isset( $values['condizione'][0] ) ? $values['condizione'][0] : 'Usato';
    $accessori = isset( $values['accessori'][0] ) ? $values['accessori'][0] : '';
    
    wp_nonce_field( 'rp_save_meta_box_data', 'rp_meta_box_nonce' );
    ?>
    <style>
        .rp-row { display: flex; gap: 1rem; margin-bottom: 1rem; }
        .rp-field { flex: 1; }
        .rp-field label { display: block; font-weight: bold; margin-bottom: 0.3rem; }
        .rp-field input, .rp-field select, .rp-field textarea { width: 100%; }
    </style>
    <div class="rp-row">
        <div class="rp-field">
            <label>Prezzo (€)</label>
            <input type="number" name="prezzo" value="<?php echo esc_attr( $prezzo ); ?>">
        </div>
        <div class="rp-field">
            <label>Anno</label>
            <input type="number" name="anno" value="<?php echo esc_attr( $anno ); ?>">
        </div>
        <div class="rp-field">
            <label>Condizione</label>
            <select name="condizione">
                <option value="Nuovo" <?php selected( $condizione, 'Nuovo' ); ?>>Nuovo</option>
                <option value="Usato" <?php selected( $condizione, 'Usato' ); ?>>Usato</option>
                <option value="Km0" <?php selected( $condizione, 'Km0' ); ?>>Km0</option>
            </select>
        </div>
    </div>
    <div class="rp-row">
        <div class="rp-field">
            <label>Posti Letto</label>
            <input type="number" name="posti_letto" value="<?php echo esc_attr( $posti ); ?>">
        </div>
        <div class="rp-field">
            <label>Peso Max (kg)</label>
            <input type="number" name="peso_massimo" value="<?php echo esc_attr( $peso ); ?>">
        </div>
        <div class="rp-field">
            <label>Lunghezza (m)</label>
            <input type="text" name="lunghezza" value="<?php echo esc_attr( $lunghezza ); ?>">
        </div>
    </div>
    <div class="rp-field">
        <label>Accessori (separati da virgola)</label>
        <textarea name="accessori" rows="3"><?php echo esc_textarea( $accessori ); ?></textarea>
        <p class="description">Es: Veranda, Mover, Climatizzatore</p>
    </div>
    <?php
}

function rp_save_meta_box_data( $post_id ) {
    if ( ! isset( $_POST['rp_meta_box_nonce'] ) || ! wp_verify_nonce( $_POST['rp_meta_box_nonce'], 'rp_save_meta_box_data' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    $fields = ['prezzo', 'anno', 'posti_letto', 'peso_massimo', 'lunghezza', 'condizione', 'accessori'];
    foreach ( $fields as $field ) {
        if ( isset( $_POST[ $field ] ) ) {
            update_post_meta( $post_id, $field, sanitize_text_field( $_POST[ $field ] ) );
        }
    }
}
add_action( 'save_post', 'rp_save_meta_box_data' );

// 3. Endpoint API per Generazione PDF (Simulato/Bridge)
// In un ambiente reale WP, useremmo una libreria PHP come TCPDF.
// Qui creiamo un endpoint che potrebbe richiamare il servizio Node.js o generare HTML stampabile.
add_action( 'rest_api_init', function () {
    register_rest_route( 'roulotte-pro/v1', '/pdf/(?P<id>\d+)', array(
        'methods' => 'GET',
        'callback' => 'rp_generate_pdf_url',
        'permission_callback' => '__return_true',
    ));
});

function rp_generate_pdf_url( $data ) {
    // In questa versione WP-only, reindirizziamo alla vista di stampa del tema
    // o integriamo una libreria PDF PHP. Per ora, restituiamo un link di stampa.
    return array( 'url' => home_url( '/?p=' . $data['id'] . '&print=pdf' ) );
}

// 4. Importatore JSON (Strumento di Migrazione)
function rp_register_import_page() {
    add_submenu_page( 'edit.php?post_type=roulotte', 'Importa JSON', 'Importa JSON', 'manage_options', 'rp-import', 'rp_render_import_page' );
}
add_action( 'admin_menu', 'rp_register_import_page' );

function rp_render_import_page() {
    ?>
    <div class="wrap">
        <h1>Importa Roulotte da JSON</h1>
        <form method="post" enctype="multipart/form-data">
            <input type="file" name="json_file" accept=".json">
            <?php submit_button('Carica e Importa'); ?>
        </form>
    </div>
    <?php
    if ( isset( $_FILES['json_file'] ) ) {
        $json = file_get_contents( $_FILES['json_file']['tmp_name'] );
        $data = json_decode( $json, true );
        
        if ( is_array( $data ) ) {
            foreach ( $data as $item ) {
                $post_data = array(
                    'post_title'    => $item['marca'] . ' ' . $item['modello'],
                    'post_content'  => isset($item['dettagli']['descrizione_testo']) ? $item['dettagli']['descrizione_testo'] : '',
                    'post_status'   => 'publish',
                    'post_type'     => 'roulotte',
                );
                
                $post_id = wp_insert_post( $post_data );
                
                if ( $post_id ) {
                    update_post_meta( $post_id, 'marca', $item['marca'] );
                    update_post_meta( $post_id, 'modello', $item['modello'] );
                    update_post_meta( $post_id, 'anno', $item['anno'] );
                    update_post_meta( $post_id, 'prezzo', isset($item['prezzo_consigliato']) ? $item['prezzo_consigliato'] : 0 );
                    
                    // Import other fields...
                    if (isset($item['accessori']) && is_array($item['accessori'])) {
                        update_post_meta( $post_id, 'accessori', implode(', ', $item['accessori']) );
                    }
                }
            }
            echo '<div class="updated"><p>Importazione completata!</p></div>';
        }
    }
}
?>